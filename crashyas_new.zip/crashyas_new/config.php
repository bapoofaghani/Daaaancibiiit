<?php
// Database configuration - update if needed
define('DB_HOST', 'localhost'); // try '127.0.0.1' if socket issues
define('DB_USER', 'aghdas');
define('DB_PASS', 'Yaser$$1365');
define('DB_NAME', 'aghdas');

// Optional: site URL (used by some apps)
define('SITE_URL', 'https://Baranbazar.sbs');

// Turn on error display for debugging (disable on production once fixed)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// You can add other global configs below if required by the app.
?>